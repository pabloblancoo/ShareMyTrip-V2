package com.sdi.business.impl.classes.Trip;

import com.sdi.model.Trip;

public class ViajeBuscar {

	public Trip buscar(Long id) {

		return null;
	}
}
