package com.sdi.model;

public enum UserStatus {
	ACTIVE, CANCELLED
}
