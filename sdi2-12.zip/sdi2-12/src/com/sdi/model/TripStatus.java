package com.sdi.model;

public enum TripStatus {
	OPEN, CLOSED, CANCELLED, DONE
}
