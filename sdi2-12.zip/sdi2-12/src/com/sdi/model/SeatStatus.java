package com.sdi.model;

public enum SeatStatus {
	ACCEPTED, EXCLUDED
}
